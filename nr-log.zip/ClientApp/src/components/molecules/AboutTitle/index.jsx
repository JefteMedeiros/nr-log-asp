import React from 'react'

export default function AboutTitle() {
  return (
    <h1 className="text-[1.8rem] lg:text-[2.2rem] mb-4">
      Somos a maior do Brasil
    </h1>
  )
}
