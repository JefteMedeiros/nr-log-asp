import React from 'react'

export default function HeaderLogo() {
  return (
    <h1 className="text-white text-2xl font-bold italic">NR Log</h1>
  )
}
