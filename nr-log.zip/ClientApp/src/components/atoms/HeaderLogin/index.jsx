import React from 'react'

export default function HeaderLogin() {
  return (
    <a href="#" className="text-white text-lg">Login</a>
  )
}
