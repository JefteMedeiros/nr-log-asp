import React from 'react'

export default function MapTitle() {
  return (
    <h1 className="text-white text-center text-[1.4rem] lg:text-[2.25rem]">Entregas para todo o Brasil! Com uma unidade física por estado</h1>
  )
}
