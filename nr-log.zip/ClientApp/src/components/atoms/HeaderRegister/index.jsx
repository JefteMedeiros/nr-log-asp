import React from 'react'

export default function HeaderRegister() {
  return (
    <a href="#" className="text-white text-lg">Registre-se</a>
  )
}
