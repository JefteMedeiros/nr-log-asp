import React from 'react'

export default function FleetTitle(props) {
  return (
    <h1 className="text-2xl text-white">{props.title}</h1>
  )
}
