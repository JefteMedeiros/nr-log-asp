import React from 'react'

export default function FleetDescription(props) {
  return (
    <h1 className="text-white">{props.description}</h1>
  )
}
