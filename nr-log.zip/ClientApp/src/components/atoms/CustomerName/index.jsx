import React from 'react'

export default function CustomerName(props) {
  return (
    <h1 className="text-white text-2xl">{props.name}</h1>
  )
}
