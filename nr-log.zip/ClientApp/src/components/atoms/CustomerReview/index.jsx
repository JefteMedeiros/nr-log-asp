import React from 'react'

export default function CustomerReview(props) {
  return (
    <h1 className="text-white">{props.review}</h1>
  )
}
