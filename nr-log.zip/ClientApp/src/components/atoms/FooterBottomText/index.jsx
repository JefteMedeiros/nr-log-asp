import React from 'react'

export default function FooterBottomText() {
  return (
    <h1 className="text-xl text-white">&copy; 2022 <span className="italic font-bold">NR Log</span></h1>
  )
}
