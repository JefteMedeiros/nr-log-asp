import React from 'react'

export default function Header() {
  return (
    <a href="#" className="text-white text-lg">Enviar remessa</a>
  )
}
