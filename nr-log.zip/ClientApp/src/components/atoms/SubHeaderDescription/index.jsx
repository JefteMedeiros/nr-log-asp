import React from 'react'

export default function SubHeaderDescription() {
  return (
    <h1 className="text-lg lg:text-2xl mt-6 lg:mt-10 text-white">Estamos entregando normalmente</h1>
  )
}
