import React from 'react'

export default function HeaderAbout() {
  return (
    <a href="#" className="text-white text-lg">Sobre</a>
  )
}
