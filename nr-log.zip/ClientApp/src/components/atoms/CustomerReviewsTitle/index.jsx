import React from 'react'

export default function CustomerReviewsTitle() {
  return (
    <h1 className="text-[2.25rem] text-center pt-3 text-white">Avaliações dos Clientes</h1>
  )
}
