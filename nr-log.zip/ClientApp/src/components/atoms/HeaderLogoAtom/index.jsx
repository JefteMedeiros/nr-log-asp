import React from 'react'

export default function HeaderLogo() {
  return (
    <div>index</div>
  )
}
