import React from 'react'

export default function OurFleet() {
  return (
    <h1 className="text-white text-center pt-3 text-[2.25rem]">Nossa Frota</h1>
  )
}
