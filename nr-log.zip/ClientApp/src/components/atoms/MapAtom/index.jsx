import React from 'react'

export default function MapAtom() {
  return (
    <>
      <img className="max-w-[100%] md:max-w-[450px]" src="img/brazil.png" alt="" />
    </>
  )
}
